-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 25, 2023 at 04:17 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `chitkara_survey_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `survey_questions`
--

CREATE TABLE `survey_questions` (
  `id` int(11) NOT NULL,
  `question` varchar(500) DEFAULT NULL,
  `option1` varchar(100) DEFAULT '-',
  `option2` varchar(100) DEFAULT '-',
  `option3` varchar(100) DEFAULT '-',
  `option4` varchar(100) DEFAULT '-',
  `questiontype` varchar(10) DEFAULT NULL,
  `topic` varchar(100) NOT NULL DEFAULT 'General'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `survey_questions`
--

INSERT INTO `survey_questions` (`id`, `question`, `option1`, `option2`, `option3`, `option4`, `questiontype`, `topic`) VALUES
(1, 'Doubt clearing Sessions conducted on a regular basis?', 'Yes', 'Sometimes', 'Never', '-', 'S', 'General'),
(2, 'How do you rate our syllabus compared with other universities?', 'Excellent', 'Very Good', 'Average', 'Low Standard', 'M', 'General'),
(3, 'Do you recommend your friends to join Chitkara?', 'Yes', 'No', '-', '-', 'S', 'General'),
(4, 'Do you get library facility in college?', 'Yes', 'No', '-', '-', 'S', 'General'),
(5, 'How do your rate Examination system?', 'Excellent', 'Very Good', 'Good', 'Average', 'S', 'Academics'),
(6, 'Your Exams were conducted as per the schedule?', 'Always', 'Sometimes', 'Never', '-', 'S', 'Schedule'),
(7, 'Do you think the Timetable was always informed well in time?', 'Always', 'Sometimes', 'Never', '-', 'S', 'Schedule'),
(8, 'question', 'a1', 'b1', 'c1', 'd1', 'M', 'Schedule');

-- --------------------------------------------------------

--
-- Table structure for table `survey_response`
--

CREATE TABLE `survey_response` (
  `responseid` int(11) NOT NULL,
  `dated` date DEFAULT NULL,
  `questionid` int(11) NOT NULL,
  `responseoption` int(11) NOT NULL,
  `userid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fname` varchar(100) DEFAULT NULL,
  `lastname` varchar(100) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `course` varchar(100) NOT NULL,
  `password` varchar(100) DEFAULT NULL,
  `role` varchar(50) NOT NULL DEFAULT 'Student'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `lastname`, `email`, `course`, `password`, `role`) VALUES
(1, 'a', 'Kaur', 'a', 'BCA', '1', 'Student'),
(2, 'Admin', 'admin', 'admin', '-', '1', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `survey_questions`
--
ALTER TABLE `survey_questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `survey_response`
--
ALTER TABLE `survey_response`
  ADD PRIMARY KEY (`responseid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `survey_response`
--
ALTER TABLE `survey_response`
  MODIFY `responseid` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
