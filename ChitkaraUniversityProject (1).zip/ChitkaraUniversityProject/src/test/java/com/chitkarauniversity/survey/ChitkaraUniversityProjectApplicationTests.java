package com.chitkarauniversity.survey;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChitkaraUniversityProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
