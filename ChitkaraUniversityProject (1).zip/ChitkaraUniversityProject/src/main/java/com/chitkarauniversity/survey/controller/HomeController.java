package com.chitkarauniversity.survey.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.chitkarauniversity.survey.model.SurveyQuestion;
import com.chitkarauniversity.survey.model.User;

import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import com.chitkarauniversity.survey.database.DatabaseAccess;

@Controller
public class HomeController {
	
	@Autowired
	   DatabaseAccess data;
	
	
	@GetMapping("/")
	public String viewHomePage()
	{
		return "index";
	}

	
	@GetMapping("/login")
	public String viewLoginPage(HttpSession session, Model model, @ModelAttribute User user)
	{
		
		return "/login";
	}
	
	
	@GetMapping("/signup")
	public String goSignUpPage(HttpSession session, Model model, @ModelAttribute User user)
	{
		
		return "/signup";
	}
	
	@PostMapping("/signup")
	public String goInsertSignUpPage(HttpSession session, Model model, @ModelAttribute User user,RedirectAttributes redirAttrs)
	{
		System.out.print(user.getFname());
		int x=data.insertUser(user);
		if (x==0)
		{
			redirAttrs.addFlashAttribute("danger", "This email is already existing!!!");
			return "redirect:/signup";
		}
		
			return "/login";
	}
	
	
	@GetMapping("/logout")
	public String goLogout(HttpSession session, Model model, @ModelAttribute User user)
	{
		Cookie cookie = new Cookie("userid", "");
		return "/login";
	}
	
	@PostMapping("/login")
	public String validateLogin(HttpSession session, Model model, @ModelAttribute User user,HttpServletResponse response)
	{
		
		List<User> users=data.validateUser(user.getUserName(), user.getPassword());
		if (users.size()==0)
				{
					return "/login";
				}
		else
		{
			session.setAttribute("username",user.getUserName() );
			session.setAttribute("userid",users.get(0).getId() );
			System.out.println("login userid="+users.get(0).getId());
			Cookie cookie = new Cookie("userid", users.get(0).getId()+"");
		    // add cookie in server response
		    response.addCookie(cookie);
			if(users.get(0).getRole().equals("Admin"))
				return "/admin/index";
			else
				return "/student/index";
		}
	}
	
	
	
	
	@GetMapping("/student")
	public String goSurvey(HttpSession session, Model model, @ModelAttribute SurveyQuestion item) {
		List<SurveyQuestion> questionsList=data.getBooks();
		
		session.setAttribute("questionsList", questionsList);
		model.addAttribute("questionsList", questionsList);
		return "/student/index";
	}
	
	
	
	@GetMapping("/admin")
	public String goAdminDashboard(HttpSession session, Model model) {
		
		return "/admin/index";
	}
	
	
	@GetMapping("/admin/questionbank")
	public String goQuestionBank(HttpSession session, Model model,@ModelAttribute SurveyQuestion item) {
		List<SurveyQuestion> questionsList=data.getBooks();
		session.setAttribute("questionsList", questionsList);
		model.addAttribute("questionsList", questionsList);
		return "/admin/questions";
	}
	
	@GetMapping("/admin/questionedit/{qid}")
	public String goQuestionEdit(HttpSession session, Model model, @PathVariable("qid") int qid,@ModelAttribute SurveyQuestion item) {
		SurveyQuestion surveyquestion=data.getQuestionById(qid);
		session.setAttribute("surveyquestion", surveyquestion);
		model.addAttribute("surveyquestion", surveyquestion);
		return "/admin/questionedit";
	}
	
	@GetMapping("/admin/questiondelete/{qid}")
	public String goQuestionDelete(HttpSession session, Model model, @PathVariable("qid") int qid,
			@ModelAttribute SurveyQuestion item,RedirectAttributes redirAttrs) {
		//calling the delete function
		int res=data.deleteQuestionById(qid);
		
		//fetching the question records and redirecting to questions bank form
		List<SurveyQuestion> questionsList=data.getBooks();
		session.setAttribute("questionsList", questionsList);
		model.addAttribute("questionsList", questionsList);
		redirAttrs.addFlashAttribute("danger", "Question Deleted!!!");
		return "redirect:/admin/questionbank";
	}
	
	@PostMapping("/admin/questionadd")
	public String goQuestionInsert(HttpSession session, Model model,@ModelAttribute("surveyquestion") SurveyQuestion surveyquestion,
			RedirectAttributes redirAttrs) {
		int id=data.insertQuestion(surveyquestion);
		
		List<SurveyQuestion> questionsList=data.getBooks();
		session.setAttribute("questionsList", questionsList);
		model.addAttribute("questionsList", questionsList);
		 redirAttrs.addFlashAttribute("success", "New Question Added");
		return "redirect:/admin/questionbank";
	}
	
	@GetMapping("/admin/questionadd")
	public String goQuestionAdd(HttpSession session, Model model,@ModelAttribute("surveyquestion") SurveyQuestion surveyquestion) {
		int id=data.getMaxQuestionId();
		System.out.println(id);
		surveyquestion.setId(id);
		session.setAttribute("surveyquestion", surveyquestion);
		model.addAttribute("surveyquestion", surveyquestion);
		return "/admin/questionadd";
	}
	
	@GetMapping("/admin/updatequestion")
	public String goQuestionUpdate(HttpSession session, Model model, @ModelAttribute("surveyquestion") SurveyQuestion 
			surveyquestion) {
		data.updateQuestion(surveyquestion);
		List<SurveyQuestion> questionsList=data.getBooks();
		session.setAttribute("questionsList", questionsList);
		model.addAttribute("questionsList", questionsList);

		return "/admin/questions";
	}
	
	@PostMapping("/admin/updatequestion")
	public String goQuestionSave(HttpSession session, Model model, @ModelAttribute("surveyquestion") SurveyQuestion surveyquestion
			,RedirectAttributes redirAttrs) {
		data.updateQuestion(surveyquestion);
		List<SurveyQuestion> questionsList=data.getBooks();
		session.setAttribute("questionsList", questionsList);
		model.addAttribute("questionsList", questionsList);
		redirAttrs.addFlashAttribute("success", "Question Updated");
		return "redirect:/admin/questionbank";
	}
	
	
	@GetMapping("/student/{surveytype}")
	public String goReview(HttpSession session, Model model, @PathVariable("surveytype") String surveytype,
			@ModelAttribute SurveyQuestion item, @CookieValue(value = "userid",
	        defaultValue = "" ) String userid) {
		System.out.println("user id="+session.getAttribute("userid"));
		System.out.println("survey type="+surveytype);
		System.out.println(userid);
		List<SurveyQuestion> questionsList=data.getBookSurveyByType(surveytype);
		session.setAttribute("questionsList", questionsList);
		model.addAttribute("questionsList", questionsList);
		return "/student/surveyform";
	}
	
	@PostMapping("/student/{surveytype}")
	public String saveFeedback(HttpSession session, Model model,@ModelAttribute("surveytypetxtbox") String surveytype1
			,@ModelAttribute SurveyQuestion item,@ModelAttribute("remarks") String remarks,@RequestParam String[] result,
			@RequestParam String[] questionid, @CookieValue(value = "userid", defaultValue = "" ) String userid) {
		System.out.println("posted type survey type="+surveytype1);
		System.out.println(remarks);
		System.out.println("Result="+result.length);
		for(int i=0;i<result.length;i++)
		{
			System.out.println(result[i]);
			data.insertSurveyResponse(userid, result[i],surveytype1,questionid[i]);
		}
		List<SurveyQuestion> questionsList=data.getBookSurveyByType(surveytype1);
		session.setAttribute("questionsList", questionsList);
		model.addAttribute("questionsList", questionsList);
		return "/student/index";
	}
	
	
	@GetMapping("/admin/surveyreportdtl")
	public String goSurveyReportDtl(HttpSession session, Model model,@ModelAttribute SurveyQuestion item) {
		List<SurveyQuestion> questionsList=data.getResponses();
		session.setAttribute("questionsList", questionsList);
		model.addAttribute("questionsList", questionsList);
		return "/admin/surveyreportdtl";
	}
	
}