package com.chitkarauniversity.survey.database;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.chitkarauniversity.survey.model.SurveyQuestion;
import com.chitkarauniversity.survey.model.User;

@Repository
public class DatabaseAccess {

	
	@Autowired 
	protected NamedParameterJdbcTemplate jdbc;
	
	
	
	public int insertUser(User user)
	{
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		//checking if user already exists
		String q1 = "Select * from users where email=:email";
		parameters.addValue("email", user.getUserName());
		List<Map<String, Object>> records=  jdbc.queryForList(q1, parameters);
		System.out.println(records.size());
		if (records.size()>0)
			return 0;
		else
		{
		
			String q = "insert into users (fname,email,course,password) values (:fname,:email,:course,:password)";
			
			parameters.addValue("fname", user.getFname());
			parameters.addValue("email", user.getUserName());
			parameters.addValue("course", user.getCourse());
			parameters.addValue("password", user.getPassword());
			
			int result=  jdbc.update(q, parameters);
			return 1;
		}
	}
	
	
	public List<SurveyQuestion> getBooks() {
		ArrayList<SurveyQuestion> items = new ArrayList<SurveyQuestion>();
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String q = "Select * from survey_questions";
		
		//parameters.addValue("userId", userId);
		
		List<Map<String, Object>> rows=  jdbc.queryForList(q, parameters);
		for(Map<String,Object> row : rows)
		{
			SurveyQuestion w=new SurveyQuestion();
			
			w.setId(Integer.parseInt(row.get("id").toString()));
			w.setQuestion(row.get("question").toString());
			w.setOption1(row.get("option1").toString());
			w.setOption2(row.get("option2").toString());
			if (row.get("option3")==null)
			{
				w.setOption3(null);
			}
			else
				w.setOption3(row.get("option3").toString());
			
			if (row.get("option4")==null)
			{
				w.setOption4(null);
			}
			else
				w.setOption4(row.get("option4").toString());
			
			w.setQuestiontype(row.get("questiontype").toString());
			w.setTopic(row.get("topic").toString());
			items.add(w);
			
		}
		System.out.println("size="+items.size());
		return items;
	}
	
	
	public List<SurveyQuestion> getResponses() {
		ArrayList<SurveyQuestion> items = new ArrayList<SurveyQuestion>();
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String q = "Select s.id,s.question,responseoption,count(responseoption) option1,s.topic from survey_questions s"
				+ " inner join survey_response r on id=questionid  group by  s.id,s.question,topic,responseoption "
				+ " order by s.question,count(responseoption) ";
		
		//parameters.addValue("userId", userId);
		
		List<Map<String, Object>> rows=  jdbc.queryForList(q, parameters);
		for(Map<String,Object> row : rows)
		{
			SurveyQuestion w=new SurveyQuestion();
			
			w.setId(Integer.parseInt(row.get("id").toString()));
			w.setQuestion(row.get("question").toString());
			w.setOption1(row.get("option1").toString());
			w.setResponse(row.get("responseoption").toString());
			
			w.setTopic(row.get("topic").toString());
			items.add(w);
			
		}
		System.out.println("size="+items.size());
		return items;
	}
	
	public List<SurveyQuestion> getBookSurveyByType(String surveytype) {
		ArrayList<SurveyQuestion> items = new ArrayList<SurveyQuestion>();
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String q = "Select * from survey_questions where topic=:surveytype";
		
		parameters.addValue("surveytype", surveytype);
		
		List<Map<String, Object>> rows=  jdbc.queryForList(q, parameters);
		for(Map<String,Object> row : rows)
		{
			SurveyQuestion w=new SurveyQuestion();
			
			w.setId(Integer.parseInt(row.get("id").toString()));
			w.setQuestion(row.get("question").toString());
			w.setOption1(row.get("option1").toString());
			w.setOption2(row.get("option2").toString());
			if (row.get("option3")==null)
			{
				w.setOption3(null);
			}
			else
				w.setOption3(row.get("option3").toString());
			
			if (row.get("option4")==null)
			{
				w.setOption4(null);
			}
			else
				w.setOption4(row.get("option4").toString());
			
			w.setQuestiontype(row.get("questiontype").toString());
			w.setTopic(row.get("topic").toString());
			items.add(w);
			
		}
		System.out.println("size="+items.size());
		return items;
	}
	
	
	public SurveyQuestion getQuestionById(int qid) {
		ArrayList<SurveyQuestion> items = new ArrayList<SurveyQuestion>();
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String q = "Select * from survey_questions where id=:qid";
		
		parameters.addValue("qid", qid);
		
		List<Map<String, Object>> rows=  jdbc.queryForList(q, parameters);
		for(Map<String,Object> row : rows)
		{
			SurveyQuestion w=new SurveyQuestion();
			
			w.setId(Integer.parseInt(row.get("id").toString()));
			w.setQuestion(row.get("question").toString());
			w.setOption1(row.get("option1").toString());
			w.setOption2(row.get("option2").toString());
			if (row.get("option3")==null)
			{
				w.setOption3(null);
			}
			else
				w.setOption3(row.get("option3").toString());
			
			if (row.get("option4")==null)
			{
				w.setOption4(null);
			}
			else
			w.setOption4(row.get("option4").toString());
			
			w.setQuestiontype(row.get("questiontype").toString());
			w.setTopic(row.get("topic").toString());
			items.add(w);
			
		}
		System.out.println("size="+items.size());
		return items.get(0);
	}
	
	
	public int deleteQuestionById(int qid) {
		ArrayList<SurveyQuestion> items = new ArrayList<SurveyQuestion>();
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String q = "delete from survey_questions where id=:qid";
		
		parameters.addValue("qid", qid);
		
		int result=  jdbc.update(q, parameters);
		return result;
	
	}
	
	public int updateQuestion(SurveyQuestion question)
	{
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String q = "update survey_questions set question=:question,option1=:op1,option2=:op2,option3=:op3,option4=:op4 "
				+ ", questiontype=:qtype,topic=:topic where id=:id";
		
		parameters.addValue("question", question.getQuestion());
		parameters.addValue("op1", question.getOption1());
		parameters.addValue("op2", question.getOption2());
		parameters.addValue("op3", question.getOption3());
		parameters.addValue("op4", question.getOption4());
		parameters.addValue("qtype", question.getQuestiontype());
		parameters.addValue("topic", question.getTopic());
		parameters.addValue("id", question.getId());
		
		int result=  jdbc.update(q, parameters);
		return 1;
	}
	
	public List<User> validateUser(String userName,String password) {
		ArrayList<User> items = new ArrayList<User>();
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String q = "Select * from users where email=:username and password=:password";
		
		parameters.addValue("username", userName);
		parameters.addValue("password", password);
		
		System.out.println(q);
		List<Map<String, Object>> rows=  jdbc.queryForList(q, parameters);
		for(Map<String,Object> row : rows)
		{
			User w=new User();
			
			w.setId(Integer.parseInt(row.get("id").toString()));
			w.setUserName(row.get("email").toString());
			w.setPassword(row.get("password").toString());
			w.setRole(row.get("role").toString());
			
			items.add(w);
			
		}
		System.out.println("size="+items.size());
		return items;
	}
	
	
	public int getMaxQuestionId() {
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String q = "Select id from survey_questions order by id desc limit 1";
		
		int id = 0;
		List<Map<String, Object>> rows=  jdbc.queryForList(q, parameters);
		for(Map<String,Object> row : rows)
		{
			
			System.out.println(row.get("id").toString());
			id=(int) row.get("id");
			break;
		}
		
		return id+1;
	}
	
	
	public int insertQuestion(SurveyQuestion question)
	{
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String q = "insert into survey_questions(id,question,option1,option2,option3,option4,questiontype,topic) values("
				+ ":id,:question,:op1,:op2,:op3,:op4,:qtype,:topic)";
		
		parameters.addValue("question", question.getQuestion());
		parameters.addValue("op1", question.getOption1());
		parameters.addValue("op2", question.getOption2());
		parameters.addValue("op3", question.getOption3());
		parameters.addValue("op4", question.getOption4());
		parameters.addValue("qtype", question.getQuestiontype());
		parameters.addValue("topic", question.getTopic());
		parameters.addValue("id", question.getId());
		
		int result=  jdbc.update(q, parameters);
		return 1;
	}
	
	public void insertSurveyResponse(String userid,String responseoption,String surveytype, String questionid)
	{
		
		MapSqlParameterSource parameters = new MapSqlParameterSource();
		String q = "insert into survey_response(dated,responseoption,surveytype,userid,questionid) values("
				+ ":dated,:responseoption,:surveytype,:userid,:questionid)";
		
		parameters.addValue("dated", "2023-04-23");
		parameters.addValue("responseoption", responseoption);
		parameters.addValue("surveytype", surveytype);
		parameters.addValue("userid", userid);
		parameters.addValue("questionid", questionid);
		
		
		
		int result=  jdbc.update(q, parameters);
		
	}
	
	
}
